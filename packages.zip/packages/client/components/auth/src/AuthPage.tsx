import { BiLogosGithub } from "solid-icons/bi";
import { JSX } from "solid-js";

import { Trans } from "@lingui/solid/macro";
import { styled } from "styled-system/jsx";

import { Titlebar } from "@revolt/app/interface/desktop/Titlebar";
import { useState } from "@revolt/state";
import { IconButton, iconSize } from "@revolt/ui";

import MdDarkMode from "@material-design-icons/svg/filled/dark_mode.svg?component-solid";

import background from "./background.jpg";
import { FlowBase } from "./flows/Flow";
import bluesky from "./flows/bluesky.svg";

/**
 * Authentication page layout
 */
const Base = styled("div", {
  base: {
    width: "100%",
    height: "100%",
    padding: "40px 35px",

    userSelect: "none",
    overflowY: "scroll",

    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",

    mdDown: {
      padding: "30px 20px",
    },
  },
});

const Root = styled("div", {
  base: {
    display: "flex",
    flexDirection: "column",
    height: "100%",
    paddingBottom: "env(keyboard-inset-height)",

                    color: "var(--md-sys-color-on-surface)",
                    background: "var(--md-sys-color-surface)",
                    // background: `var(--url)`,
                    // backgroundPosition: "center",
                    // backgroundRepeat: "no-repeat",
                    // backgroundSize: "cover",
  },
});

/**
 * Top and bottom navigation bars
 */
const Nav = styled("div", {
  base: {
    height: "32px",
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",

    textDecoration: "none",
  },
});

/**
 * Navigation items
 */
const NavItems = styled("div", {
  base: {
    gap: "10px",
    display: "flex",
    alignItems: "center",

    fontSize: "0.9em",
  },
  variants: {
    variant: {
      default: {
        "& > *": {
          textAlign: "center",
        },
      },
      stack: {
        md: {
          flexDirection: "column",
        },
      },
    },
  },
  defaultVariants: {
    variant: "default",
  },
});

/**
 * Link with an icon inside
 */
const LinkWithIcon = styled("a", {
  base: { height: "24px" },
});

/**
 * Middot-like bullet
 */
const Bullet = styled("div", {
  base: {
    height: "5px",
    width: "5px",
    background: "grey",
    borderRadius: "50%",

    md: {
      display: "none",
    },
  },
});

/**
 * Authentication page
 */
export function AuthPage(props: { children: JSX.Element }) {
  const state = useState();

  return (
    <Root>
    <Titlebar />
    <Base
    style={{ "--url": `url('${background}')` }}
    css={{ scrollbar: "hidden" }}
    >
    <Nav>
    <div />
    <IconButton
    variant="tonal"
    onPress={() =>
      state.theme.setMode(
        state.theme.activeTheme.darkMode ? "light" : "dark",
      )
    }
    >
    <MdDarkMode {...iconSize("24px")} />
    </IconButton>
    </Nav>
    <FlowBase>{props.children}</FlowBase>
    <Nav>
    <NavItems variant="stack">
    <Bullet />
    <NavItems>
    <a href="https://github.com/stoatchat/for-web/blob/main/LICENSE" target="_blank">
    <Trans>License</Trans>
    </a>
    <a href="https://github.com/stoatchat/for-web/releases/tag/stoat-for-web-v0.15.0" target="_blank">
    <Trans>Base Source Code</Trans>
    </a>
    <a href="https://github.com/PocketDerg/Uncensored/tree/main" target="_blank">
    <Trans>Uncensored Source Code</Trans>
    </a>
    </NavItems>
    </NavItems>
    </Nav>
    </Base>
    </Root>
  );
}
